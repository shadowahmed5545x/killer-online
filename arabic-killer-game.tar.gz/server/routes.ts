import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { testDatabaseConnection } from "./db";
import { insertRoomSchema, insertPlayerSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

interface ClientInfo {
  playerId?: number;
  roomId?: number;
  playerName?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Store client connections with their info
  const clients = new Map<WebSocket, ClientInfo>();
  
  // Helper function to broadcast to room
  function broadcastToRoom(roomId: number, message: any, excludeClient?: WebSocket) {
    clients.forEach((clientInfo, client) => {
      if (client !== excludeClient && 
          clientInfo.roomId === roomId && 
          client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }
  
  // Helper function to generate room code
  function generateRoomCode(): string {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }
  
  // Helper function to assign roles
  function assignRoles(players: any[]): void {
    if (players.length < 3) return;
    
    // Shuffle players
    const shuffled = [...players].sort(() => Math.random() - 0.5);
    
    // Assign one killer
    const killerIndex = Math.floor(Math.random() * shuffled.length);
    shuffled.forEach((player, index) => {
      storage.updatePlayerRole(player.id, index === killerIndex ? 'killer' : 'civilian');
    });
  }
  
  wss.on('connection', (ws: WebSocket) => {
    clients.set(ws, {});
    
    // Handle WebSocket errors
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
    
    ws.on('message', async (data: string) => {
      try {
        const message = JSON.parse(data);
        const clientInfo = clients.get(ws);
        
        switch (message.type) {
          case 'join_room':
            const { playerName, roomCode } = message.data;
            
            if (!playerName || !roomCode) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'اسم اللاعب ورمز الغرفة مطلوبان'
              }));
              return;
            }
            
            // Find or create room
            let room = await storage.getRoomByCode(roomCode);
            if (!room) {
              // Create new room
              room = await storage.createRoom({
                code: roomCode,
                name: `غرفة ${roomCode}`,
                hostId: 1, // Will be updated with first player
                maxPlayers: 6,
                status: 'lobby'
              });
            }
            
            // Check if room is full
            const existingPlayers = await storage.getPlayersByRoomId(room.id);
            if (existingPlayers.length >= room.maxPlayers) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'الغرفة ممتلئة'
              }));
              return;
            }
            
            // Check if player name already exists in room
            const nameExists = existingPlayers.some(p => p.name === playerName);
            if (nameExists) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'اسم اللاعب موجود مسبقاً في الغرفة'
              }));
              return;
            }
            
            // Create player
            const player = await storage.createPlayer({
              name: playerName,
              roomId: room.id,
              isHost: existingPlayers.length === 0,
              role: 'civilian',
              isAlive: true,
              isConnected: true
            });
            
            // Update client info
            clients.set(ws, {
              playerId: player.id,
              roomId: room.id,
              playerName: playerName
            });
            
            // Send join success
            ws.send(JSON.stringify({
              type: 'join_success',
              data: {
                playerId: player.id,
                roomId: room.id,
                roomCode: room.code,
                isHost: player.isHost
              }
            }));
            
            // Create system message
            await storage.createMessage({
              roomId: room.id,
              playerId: null,
              senderName: 'النظام',
              content: `انضم ${playerName} للغرفة`,
              type: 'system'
            });
            
            // Broadcast updates to all players in room
            const updatedPlayers = await storage.getPlayersByRoomId(room.id);
            const messages = await storage.getMessagesByRoomId(room.id);
            
            broadcastToRoom(room.id, {
              type: 'players_update',
              data: updatedPlayers
            });
            
            broadcastToRoom(room.id, {
              type: 'messages_update', 
              data: messages
            });
            
            break;
            
          case 'create_room':
            const { playerName: hostName } = message.data;
            
            if (!hostName) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'اسم اللاعب مطلوب'
              }));
              return;
            }
            
            // Generate unique room code
            let newRoomCode;
            let attempts = 0;
            do {
              newRoomCode = generateRoomCode();
              attempts++;
            } while (await storage.getRoomByCode(newRoomCode) && attempts < 10);
            
            if (attempts >= 10) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'فشل في إنشاء غرفة جديدة'
              }));
              return;
            }
            
            // Create room
            const newRoom = await storage.createRoom({
              code: newRoomCode,
              name: `غرفة ${newRoomCode}`,
              hostId: 1,
              maxPlayers: 6,
              status: 'lobby'
            });
            
            // Create host player
            const hostPlayer = await storage.createPlayer({
              name: hostName,
              roomId: newRoom.id,
              isHost: true,
              role: 'civilian',
              isAlive: true,
              isConnected: true
            });
            
            // Update client info
            clients.set(ws, {
              playerId: hostPlayer.id,
              roomId: newRoom.id,
              playerName: hostName
            });
            
            // Send success
            ws.send(JSON.stringify({
              type: 'join_success',
              data: {
                playerId: hostPlayer.id,
                roomId: newRoom.id,
                roomCode: newRoom.code,
                isHost: true
              }
            }));
            
            // Create system message
            await storage.createMessage({
              roomId: newRoom.id,
              playerId: null,
              senderName: 'النظام',
              content: `تم إنشاء الغرفة بواسطة ${hostName}`,
              type: 'system'
            });
            
            const initialPlayers = await storage.getPlayersByRoomId(newRoom.id);
            const initialMessages = await storage.getMessagesByRoomId(newRoom.id);
            
            ws.send(JSON.stringify({
              type: 'players_update',
              data: initialPlayers
            }));
            
            ws.send(JSON.stringify({
              type: 'messages_update',
              data: initialMessages
            }));
            
            break;
            
          case 'send_message':
            const { content } = message.data;
            
            if (!clientInfo?.playerId || !clientInfo?.roomId || !content?.trim()) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'رسالة غير صحيحة'
              }));
              return;
            }
            
            // Create message
            const newMessage = await storage.createMessage({
              roomId: clientInfo.roomId,
              playerId: clientInfo.playerId,
              senderName: clientInfo.playerName || 'مجهول',
              content: content.trim(),
              type: 'chat'
            });
            
            // Broadcast to room
            const allMessages = await storage.getMessagesByRoomId(clientInfo.roomId);
            broadcastToRoom(clientInfo.roomId, {
              type: 'messages_update',
              data: allMessages
            });
            
            break;
            
          case 'start_game':
            if (!clientInfo?.playerId || !clientInfo?.roomId) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'غير مصرح'
              }));
              return;
            }
            
            const currentPlayer = await storage.getPlayerById(clientInfo.playerId);
            if (!currentPlayer?.isHost) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'فقط مضيف الغرفة يمكنه بدء اللعبة'
              }));
              return;
            }
            
            const roomPlayers = await storage.getPlayersByRoomId(clientInfo.roomId);
            if (roomPlayers.length < 3) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'يجب وجود 3 لاعبين على الأقل لبدء اللعبة'
              }));
              return;
            }
            
            // Update room status
            await storage.updateRoomStatus(clientInfo.roomId, 'in_game');
            
            // Assign roles
            assignRoles(roomPlayers);
            
            // Create system message
            await storage.createMessage({
              roomId: clientInfo.roomId,
              playerId: null,
              senderName: 'النظام',
              content: 'بدأت اللعبة! تم توزيع الأدوار',
              type: 'system'
            });
            
            // Broadcast game start
            const gameStartPlayers = await storage.getPlayersByRoomId(clientInfo.roomId);
            const gameStartMessages = await storage.getMessagesByRoomId(clientInfo.roomId);
            
            broadcastToRoom(clientInfo.roomId, {
              type: 'game_started',
              data: {
                players: gameStartPlayers,
                messages: gameStartMessages
              }
            });
            
            break;
            
          case 'reset_game':
            if (!clientInfo?.playerId || !clientInfo?.roomId) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'غير مصرح'
              }));
              return;
            }
            
            const resetPlayer = await storage.getPlayerById(clientInfo.playerId);
            if (!resetPlayer?.isHost) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'فقط مضيف الغرفة يمكنه إعادة تعيين اللعبة'
              }));
              return;
            }
            
            // Update room status
            await storage.updateRoomStatus(clientInfo.roomId, 'lobby');
            
            // Reset all player roles and alive status
            const resetPlayers = await storage.getPlayersByRoomId(clientInfo.roomId);
            for (const player of resetPlayers) {
              await storage.updatePlayerRole(player.id, 'civilian');
              await storage.updatePlayerAlive(player.id, true);
            }
            
            // Create system message
            await storage.createMessage({
              roomId: clientInfo.roomId,
              playerId: null,
              senderName: 'النظام',
              content: 'تم إعادة تعيين اللعبة',
              type: 'system'
            });
            
            // Broadcast reset
            const resetPlayersUpdated = await storage.getPlayersByRoomId(clientInfo.roomId);
            const resetMessages = await storage.getMessagesByRoomId(clientInfo.roomId);
            
            broadcastToRoom(clientInfo.roomId, {
              type: 'game_reset',
              data: {
                players: resetPlayersUpdated,
                messages: resetMessages
              }
            });
            
            break;
            
          case 'start_vote':
            if (!clientInfo?.playerId || !clientInfo?.roomId) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'غير مصرح'
              }));
              return;
            }
            
            const voteRoom = await storage.getRoomById(clientInfo.roomId);
            if (!voteRoom || voteRoom.status !== 'in_game') {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'اللعبة غير نشطة'
              }));
              return;
            }
            
            const alivePlayers = await storage.getPlayersByRoomId(clientInfo.roomId);
            const alivePlayerList = alivePlayers.filter(p => p.isAlive && p.isConnected);
            
            if (alivePlayerList.length < 2) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'لا يوجد لاعبين كافيين للتصويت'
              }));
              return;
            }
            
            // Create new game round for voting
            const currentRound = await storage.getCurrentRound(clientInfo.roomId);
            const newRound = currentRound ? currentRound.round + 1 : 1;
            
            await storage.createGameRound({
              roomId: clientInfo.roomId,
              round: newRound,
              phase: 'voting',
              eliminatedPlayerId: null
            });
            
            // Clear any existing votes for this round
            await storage.clearVotes(clientInfo.roomId, newRound);
            
            // Create system message
            await storage.createMessage({
              roomId: clientInfo.roomId,
              playerId: null,
              senderName: 'النظام',
              content: '🗳️ بدأت مرحلة التصويت! اختر من تريد طرده',
              type: 'system'
            });
            
            broadcastToRoom(clientInfo.roomId, {
              type: 'start_vote',
              data: {
                players: alivePlayerList,
                round: newRound
              }
            });
            
            const voteMessages = await storage.getMessagesByRoomId(clientInfo.roomId);
            broadcastToRoom(clientInfo.roomId, {
              type: 'messages_update',
              data: voteMessages
            });
            
            break;
            
          case 'submit_vote':
            const { targetPlayerId } = message.data;
            
            if (!clientInfo?.playerId || !clientInfo?.roomId || !targetPlayerId) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'بيانات التصويت غير صحيحة'
              }));
              return;
            }
            
            const voter = await storage.getPlayerById(clientInfo.playerId);
            if (!voter || !voter.isAlive) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'لا يمكن للاعبين المتوفين التصويت'
              }));
              return;
            }
            
            const voteRound = await storage.getCurrentRound(clientInfo.roomId);
            if (!voteRound || voteRound.phase !== 'voting') {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'ليس وقت التصويت'
              }));
              return;
            }
            
            // Check if already voted
            const existingVotes = await storage.getVotesByRoomId(clientInfo.roomId, voteRound.round);
            const alreadyVoted = existingVotes.some(v => v.voterId === clientInfo.playerId);
            
            if (alreadyVoted) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'لقد صوت بالفعل'
              }));
              return;
            }
            
            // Create vote
            await storage.createVote({
              roomId: clientInfo.roomId,
              voterId: clientInfo.playerId,
              targetId: targetPlayerId,
              voteRound: voteRound.round
            });
            
            // Check if all alive players have voted
            const allVotingPlayers = await storage.getPlayersByRoomId(clientInfo.roomId);
            const aliveVotingPlayers = allVotingPlayers.filter(p => p.isAlive && p.isConnected);
            const totalVotes = await storage.getVotesByRoomId(clientInfo.roomId, voteRound.round);
            
            if (totalVotes.length >= aliveVotingPlayers.length) {
              // Calculate vote results
              const voteCount: { [key: number]: number } = {};
              totalVotes.forEach(vote => {
                voteCount[vote.targetId] = (voteCount[vote.targetId] || 0) + 1;
              });
              
              // Find player with most votes
              let maxVotes = 0;
              let eliminatedPlayerId = null;
              
              for (const [playerId, votes] of Object.entries(voteCount)) {
                if (votes > maxVotes) {
                  maxVotes = votes;
                  eliminatedPlayerId = parseInt(playerId);
                }
              }
              
              if (eliminatedPlayerId) {
                const eliminatedPlayer = await storage.getPlayerById(eliminatedPlayerId);
                if (eliminatedPlayer) {
                  // Update eliminated player
                  await storage.updatePlayerAlive(eliminatedPlayerId, false);
                  
                  // Update round with eliminated player
                  await storage.updateRoundPhase(clientInfo.roomId, voteRound.round, 'completed');
                  
                  // Create elimination message
                  await storage.createMessage({
                    roomId: clientInfo.roomId,
                    playerId: null,
                    senderName: 'النظام',
                    content: `🗳️ تم طرد ${eliminatedPlayer.name} من اللعبة! (${maxVotes} أصوات)`,
                    type: 'system'
                  });
                  
                  // Check win conditions
                  const remainingPlayers = await storage.getPlayersByRoomId(clientInfo.roomId);
                  const alivePlayers = remainingPlayers.filter(p => p.isAlive);
                  const killer = alivePlayers.find(p => p.role === 'killer');
                  const civilians = alivePlayers.filter(p => p.role === 'civilian');
                  
                  let gameOver = false;
                  let winner = '';
                  let reason = '';
                  
                  if (!killer || eliminatedPlayer.role === 'killer') {
                    // Civilians win - killer eliminated
                    gameOver = true;
                    winner = 'المدنيين 👨‍🌾';
                    reason = 'تم طرد القاتل!';
                  } else if (civilians.length <= 1) {
                    // Killer wins - civilians eliminated
                    gameOver = true;
                    winner = 'القاتل 🗡️';
                    reason = 'تم قتل كل المدنيين!';
                  }
                  
                  if (gameOver) {
                    await storage.updateRoomStatus(clientInfo.roomId, 'finished');
                    
                    await storage.createMessage({
                      roomId: clientInfo.roomId,
                      playerId: null,
                      senderName: 'النظام',
                      content: `🏁 انتهت اللعبة! الفائز: ${winner} - ${reason}`,
                      type: 'system'
                    });
                    
                    broadcastToRoom(clientInfo.roomId, {
                      type: 'game_over',
                      data: {
                        winner,
                        reason,
                        eliminatedPlayer: eliminatedPlayer.name,
                        players: await storage.getPlayersByRoomId(clientInfo.roomId),
                        messages: await storage.getMessagesByRoomId(clientInfo.roomId)
                      }
                    });
                  } else {
                    // Continue game
                    broadcastToRoom(clientInfo.roomId, {
                      type: 'vote_result',
                      data: {
                        eliminatedPlayer: eliminatedPlayer.name,
                        votes: maxVotes,
                        players: await storage.getPlayersByRoomId(clientInfo.roomId),
                        messages: await storage.getMessagesByRoomId(clientInfo.roomId)
                      }
                    });
                  }
                }
              }
            } else {
              // Inform that vote was recorded
              ws.send(JSON.stringify({
                type: 'vote_recorded',
                data: {
                  votesReceived: totalVotes.length,
                  totalPlayers: aliveVotingPlayers.length
                }
              }));
            }
            
            break;
            
          case 'kill_player':
            const { targetId } = message.data;
            
            if (!clientInfo?.playerId || !clientInfo?.roomId || !targetId) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'بيانات القتل غير صحيحة'
              }));
              return;
            }
            
            const killer = await storage.getPlayerById(clientInfo.playerId);
            if (!killer || killer.role !== 'killer') {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'فقط القاتل يمكنه القتل'
              }));
              return;
            }
            
            const target = await storage.getPlayerById(targetId);
            if (!target || !target.isAlive) {
              ws.send(JSON.stringify({
                type: 'error',
                message: 'الهدف غير صحيح'
              }));
              return;
            }
            
            // Kill the target
            await storage.updatePlayerAlive(targetId, false);
            
            // Create kill message
            await storage.createMessage({
              roomId: clientInfo.roomId,
              playerId: null,
              senderName: 'النظام',
              content: `💀 تم قتل ${target.name} في الليل!`,
              type: 'system'
            });
            
            // Check win conditions
            const remainingAfterKill = await storage.getPlayersByRoomId(clientInfo.roomId);
            const aliveAfterKill = remainingAfterKill.filter(p => p.isAlive);
            const civiliansAfterKill = aliveAfterKill.filter(p => p.role === 'civilian');
            
            if (civiliansAfterKill.length <= 1) {
              // Killer wins
              await storage.updateRoomStatus(clientInfo.roomId, 'finished');
              
              await storage.createMessage({
                roomId: clientInfo.roomId,
                playerId: null,
                senderName: 'النظام',
                content: '🏁 انتهت اللعبة! الفائز: القاتل 🗡️ - تم قتل كل المدنيين!',
                type: 'system'
              });
              
              broadcastToRoom(clientInfo.roomId, {
                type: 'game_over',
                data: {
                  winner: 'القاتل 🗡️',
                  reason: 'تم قتل كل المدنيين!',
                  killedPlayer: target.name,
                  players: await storage.getPlayersByRoomId(clientInfo.roomId),
                  messages: await storage.getMessagesByRoomId(clientInfo.roomId)
                }
              });
            } else {
              // Continue game - broadcast kill
              broadcastToRoom(clientInfo.roomId, {
                type: 'player_killed',
                data: {
                  killedPlayer: target.name,
                  players: await storage.getPlayersByRoomId(clientInfo.roomId),
                  messages: await storage.getMessagesByRoomId(clientInfo.roomId)
                }
              });
            }
            
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'خطأ في الخادم'
        }));
      }
    });
    
    ws.on('close', async () => {
      const clientInfo = clients.get(ws);
      if (clientInfo?.playerId && clientInfo?.roomId) {
        // Update player connection status
        await storage.updatePlayerConnection(clientInfo.playerId, false);
        
        // Create system message
        await storage.createMessage({
          roomId: clientInfo.roomId,
          playerId: null,
          senderName: 'النظام',
          content: `غادر ${clientInfo.playerName} الغرفة`,
          type: 'system'
        });
        
        // Broadcast updates
        const updatedPlayers = await storage.getPlayersByRoomId(clientInfo.roomId);
        const messages = await storage.getMessagesByRoomId(clientInfo.roomId);
        
        broadcastToRoom(clientInfo.roomId, {
          type: 'players_update',
          data: updatedPlayers
        }, ws);
        
        broadcastToRoom(clientInfo.roomId, {
          type: 'messages_update',
          data: messages
        }, ws);
      }
      
      clients.delete(ws);
    });
  });

  // Keep alive endpoint for UptimeRobot (prevents app from sleeping)
  app.get('/api/ping', (req, res) => {
    res.json({ 
      status: 'alive', 
      message: 'Arabic Killer Game is running',
      timestamp: new Date().toISOString(),
      uptime: Math.floor(process.uptime()),
      players_online: clients.size
    });
  });

  // Health check endpoint
  app.get('/api/health', async (req, res) => {
    try {
      const dbStatus = await testDatabaseConnection();
      res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        database: dbStatus ? 'connected' : 'error'
      });
    } catch (error) {
      res.status(500).json({ 
        status: 'ERROR', 
        timestamp: new Date().toISOString(),
        database: 'error',
        error: error.message
      });
    }
  });

  return httpServer;
}
