import { rooms, players, messages, users, votes, gameRounds, type Room, type Player, type Message, type User, type Vote, type GameRound, type InsertRoom, type InsertPlayer, type InsertMessage, type InsertUser, type InsertVote, type InsertGameRound } from "@shared/schema";
import { db } from './db';
import { eq, and, desc } from 'drizzle-orm';

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Room methods
  createRoom(room: InsertRoom): Promise<Room>;
  getRoomByCode(code: string): Promise<Room | undefined>;
  getRoomById(id: number): Promise<Room | undefined>;
  updateRoomStatus(id: number, status: string): Promise<void>;
  deleteRoom(id: number): Promise<void>;
  
  // Player methods
  createPlayer(player: InsertPlayer): Promise<Player>;
  getPlayersByRoomId(roomId: number): Promise<Player[]>;
  getPlayerById(id: number): Promise<Player | undefined>;
  updatePlayerConnection(id: number, isConnected: boolean): Promise<void>;
  updatePlayerRole(id: number, role: string): Promise<void>;
  updatePlayerAlive(id: number, isAlive: boolean): Promise<void>;
  removePlayer(id: number): Promise<void>;
  
  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByRoomId(roomId: number): Promise<Message[]>;
  
  // Vote methods
  createVote(vote: InsertVote): Promise<Vote>;
  getVotesByRoomId(roomId: number, voteRound: number): Promise<Vote[]>;
  clearVotes(roomId: number, voteRound: number): Promise<void>;
  
  // Game Round methods
  createGameRound(round: InsertGameRound): Promise<GameRound>;
  getCurrentRound(roomId: number): Promise<GameRound | undefined>;
  updateRoundPhase(roomId: number, round: number, phase: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Room methods
  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const [room] = await db.insert(rooms).values(insertRoom).returning();
    return room;
  }

  async getRoomByCode(code: string): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.code, code));
    return room || undefined;
  }

  async getRoomById(id: number): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room || undefined;
  }

  async updateRoomStatus(id: number, status: string): Promise<void> {
    await db.update(rooms).set({ status }).where(eq(rooms.id, id));
  }

  async deleteRoom(id: number): Promise<void> {
    await db.delete(rooms).where(eq(rooms.id, id));
    // Also remove players and messages for this room
    await db.delete(players).where(eq(players.roomId, id));
    await db.delete(messages).where(eq(messages.roomId, id));
  }

  // Player methods
  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const [player] = await db.insert(players).values(insertPlayer).returning();
    return player;
  }

  async getPlayersByRoomId(roomId: number): Promise<Player[]> {
    return await db.select().from(players).where(eq(players.roomId, roomId));
  }

  async getPlayerById(id: number): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.id, id));
    return player || undefined;
  }

  async updatePlayerConnection(id: number, isConnected: boolean): Promise<void> {
    await db.update(players).set({ isConnected }).where(eq(players.id, id));
  }

  async updatePlayerRole(id: number, role: string): Promise<void> {
    await db.update(players).set({ role }).where(eq(players.id, id));
  }

  async updatePlayerAlive(id: number, isAlive: boolean): Promise<void> {
    await db.update(players).set({ isAlive }).where(eq(players.id, id));
  }

  async removePlayer(id: number): Promise<void> {
    await db.delete(players).where(eq(players.id, id));
  }

  // Message methods
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(insertMessage).returning();
    return message;
  }

  async getMessagesByRoomId(roomId: number): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.roomId, roomId)).orderBy(messages.sentAt);
  }

  // Vote methods
  async createVote(insertVote: InsertVote): Promise<Vote> {
    const [vote] = await db.insert(votes).values(insertVote).returning();
    return vote;
  }

  async getVotesByRoomId(roomId: number, voteRound: number): Promise<Vote[]> {
    return await db.select().from(votes).where(and(eq(votes.roomId, roomId), eq(votes.voteRound, voteRound)));
  }

  async clearVotes(roomId: number, voteRound: number): Promise<void> {
    await db.delete(votes).where(and(eq(votes.roomId, roomId), eq(votes.voteRound, voteRound)));
  }

  // Game Round methods
  async createGameRound(insertGameRound: InsertGameRound): Promise<GameRound> {
    const [gameRound] = await db.insert(gameRounds).values(insertGameRound).returning();
    return gameRound;
  }

  async getCurrentRound(roomId: number): Promise<GameRound | undefined> {
    const [gameRound] = await db.select().from(gameRounds)
      .where(eq(gameRounds.roomId, roomId))
      .orderBy(desc(gameRounds.round))
      .limit(1);
    return gameRound || undefined;
  }

  async updateRoundPhase(roomId: number, round: number, phase: string): Promise<void> {
    await db.update(gameRounds)
      .set({ phase })
      .where(and(eq(gameRounds.roomId, roomId), eq(gameRounds.round, round)));
  }
}

export const storage = new DatabaseStorage();
