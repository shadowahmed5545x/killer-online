import { useState, useEffect } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  Users, 
  MessageCircle, 
  Play, 
  RotateCcw, 
  Plus, 
  LogIn, 
  Settings, 
  Skull, 
  Shield, 
  Clock, 
  Heart,
  DoorOpen,
  Key,
  User
} from "lucide-react";

interface Player {
  id: number;
  name: string;
  roomId: number;
  isHost: boolean;
  role: string;
  isAlive: boolean;
  isConnected: boolean;
  joinedAt: string;
}

interface Message {
  id: number;
  roomId: number;
  playerId: number | null;
  senderName: string;
  content: string;
  type: string;
  sentAt: string;
}

interface GameState {
  playerId: number | null;
  roomId: number | null;
  roomCode: string;
  isHost: boolean;
  players: Player[];
  messages: Message[];
  gameStatus: string;
  isConnected: boolean;
  isVoting: boolean;
  votingPlayers: Player[];
  votingRound: number;
  eliminatedPlayers: string[];
  gameOverData: {
    winner: string;
    reason: string;
    show: boolean;
  };
}

export default function Home() {
  const { toast } = useToast();
  const [playerName, setPlayerName] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [chatMessage, setChatMessage] = useState("");
  const [gameState, setGameState] = useState<GameState>({
    playerId: null,
    roomId: null,
    roomCode: "",
    isHost: false,
    players: [],
    messages: [],
    gameStatus: "lobby",
    isConnected: false,
    isVoting: false,
    votingPlayers: [],
    votingRound: 0,
    eliminatedPlayers: [],
    gameOverData: {
      winner: "",
      reason: "",
      show: false
    }
  });

  const { socket, isConnected } = useWebSocket({
    onMessage: (message) => {
      switch (message.type) {
        case 'join_success':
          setGameState(prev => ({
            ...prev,
            playerId: message.data.playerId,
            roomId: message.data.roomId,
            roomCode: message.data.roomCode,
            isHost: message.data.isHost,
            isConnected: true
          }));
          toast({
            title: "تم الانضمام بنجاح",
            description: `مرحباً بك في غرفة ${message.data.roomCode}`,
          });
          break;
        
        case 'players_update':
          setGameState(prev => ({
            ...prev,
            players: message.data
          }));
          break;
        
        case 'messages_update':
          setGameState(prev => ({
            ...prev,
            messages: message.data
          }));
          break;
        
        case 'game_started':
          setGameState(prev => ({
            ...prev,
            gameStatus: "in_game",
            players: message.data.players,
            messages: message.data.messages
          }));
          toast({
            title: "بدأت اللعبة!",
            description: "تم توزيع الأدوار",
          });
          break;
        
        case 'game_reset':
          setGameState(prev => ({
            ...prev,
            gameStatus: "lobby",
            players: message.data.players,
            messages: message.data.messages
          }));
          toast({
            title: "تم إعادة تعيين اللعبة",
            description: "العودة إلى اللوبي",
          });
          break;
        
        case 'start_vote':
          setGameState(prev => ({
            ...prev,
            isVoting: true,
            votingPlayers: message.data.players,
            votingRound: message.data.round
          }));
          toast({
            title: "بدء التصويت",
            description: "اختر من تريد طرده من اللعبة",
          });
          break;
        
        case 'vote_recorded':
          toast({
            title: "تم تسجيل صوتك",
            description: `${message.data.votesReceived}/${message.data.totalPlayers} لاعب صوت`,
          });
          break;
        
        case 'vote_result':
          setGameState(prev => ({
            ...prev,
            isVoting: false,
            players: message.data.players,
            messages: message.data.messages,
            eliminatedPlayers: [...prev.eliminatedPlayers, message.data.eliminatedPlayer]
          }));
          toast({
            title: "نتيجة التصويت",
            description: `تم طرد ${message.data.eliminatedPlayer} (${message.data.votes} أصوات)`,
          });
          break;
        
        case 'player_killed':
          setGameState(prev => ({
            ...prev,
            players: message.data.players,
            messages: message.data.messages,
            eliminatedPlayers: [...prev.eliminatedPlayers, message.data.killedPlayer]
          }));
          toast({
            title: "تم القتل",
            description: `تم قتل ${message.data.killedPlayer} في الليل`,
            variant: "destructive",
          });
          break;
        
        case 'game_over':
          setGameState(prev => ({
            ...prev,
            gameStatus: "finished",
            players: message.data.players,
            messages: message.data.messages,
            isVoting: false,
            gameOverData: {
              winner: message.data.winner,
              reason: message.data.reason,
              show: true
            },
            eliminatedPlayers: message.data.eliminatedPlayer ? 
              [...prev.eliminatedPlayers, message.data.eliminatedPlayer] : 
              prev.eliminatedPlayers
          }));
          toast({
            title: "انتهت اللعبة!",
            description: `الفائز: ${message.data.winner}`,
          });
          break;
        
        case 'error':
          toast({
            title: "خطأ",
            description: message.message,
            variant: "destructive",
          });
          break;
      }
    }
  });

  const handleJoinRoom = () => {
    if (!playerName.trim() || !roomCode.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اسم اللاعب ورمز الغرفة",
        variant: "destructive",
      });
      return;
    }

    socket?.send(JSON.stringify({
      type: 'join_room',
      data: { playerName: playerName.trim(), roomCode: roomCode.trim().toUpperCase() }
    }));
  };

  const handleCreateRoom = () => {
    if (!playerName.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اسم اللاعب",
        variant: "destructive",
      });
      return;
    }

    socket?.send(JSON.stringify({
      type: 'create_room',
      data: { playerName: playerName.trim() }
    }));
  };

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;

    socket?.send(JSON.stringify({
      type: 'send_message',
      data: { content: chatMessage.trim() }
    }));
    setChatMessage("");
  };

  const handleStartGame = () => {
    socket?.send(JSON.stringify({
      type: 'start_game',
      data: {}
    }));
  };

  const handleResetGame = () => {
    socket?.send(JSON.stringify({
      type: 'reset_game',
      data: {}
    }));
  };

  const handleStartVote = () => {
    socket?.send(JSON.stringify({
      type: 'start_vote',
      data: {}
    }));
  };

  const handleVote = (targetPlayerId: number) => {
    socket?.send(JSON.stringify({
      type: 'submit_vote',
      data: { targetPlayerId }
    }));
  };

  const handleKillPlayer = (targetId: number) => {
    socket?.send(JSON.stringify({
      type: 'kill_player',
      data: { targetId }
    }));
  };

  const handleRestartGame = () => {
    setGameState({
      playerId: null,
      roomId: null,
      roomCode: "",
      isHost: false,
      players: [],
      messages: [],
      gameStatus: "lobby",
      isConnected: false,
      isVoting: false,
      votingPlayers: [],
      votingRound: 0,
      eliminatedPlayers: [],
      gameOverData: {
        winner: "",
        reason: "",
        show: false
      }
    });
    setPlayerName("");
    setRoomCode("");
    setChatMessage("");
  };

  const connectedPlayers = gameState.players.filter(p => p.isConnected);
  const currentPlayer = gameState.players.find(p => p.id === gameState.playerId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-game-bg via-gray-900 to-game-bg">
      {/* Navigation Header */}
      <nav className="bg-game-card/50 backdrop-blur-sm border-b border-game-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-reverse space-x-4">
              <div className="flex items-center">
                <Skull className="text-game-accent text-2xl ml-3" />
                <h1 className="text-xl font-bold text-game-text">من هو القاتل؟</h1>
              </div>
              <div className="hidden md:flex items-center space-x-reverse space-x-4">
                <span className="text-game-text-secondary text-sm">لعبة متعددة اللاعبين</span>
              </div>
            </div>
            <div className="flex items-center space-x-reverse space-x-4">
              <div className="flex items-center bg-game-success/20 px-3 py-1 rounded-full">
                <div className={`w-2 h-2 rounded-full ml-2 ${isConnected ? 'bg-game-success animate-pulse' : 'bg-gray-500'}`}></div>
                <span className={`text-sm font-medium ${isConnected ? 'text-game-success' : 'text-gray-500'}`}>
                  {isConnected ? 'متصل' : 'غير متصل'}
                </span>
              </div>
              <Button variant="ghost" size="sm" className="p-2 rounded-lg hover:bg-game-card">
                <Settings className="text-game-text-secondary" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Game Status Section */}
        <div className="mb-8">
          <Card className="bg-game-card/50 backdrop-blur-sm border border-game-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-game-text">حالة اللعبة</h2>
                <div className="flex items-center space-x-reverse space-x-2">
                  <div className={`w-3 h-3 rounded-full animate-pulse ${
                    gameState.gameStatus === 'lobby' ? 'bg-game-warning' : 
                    gameState.gameStatus === 'in_game' ? 'bg-game-success' : 'bg-gray-500'
                  }`}></div>
                  <span className={`font-medium ${
                    gameState.gameStatus === 'lobby' ? 'text-game-warning' : 
                    gameState.gameStatus === 'in_game' ? 'text-game-success' : 'text-gray-500'
                  }`}>
                    {gameState.gameStatus === 'lobby' ? 'في انتظار اللاعبين' : 
                     gameState.gameStatus === 'in_game' ? 'اللعبة جارية' : 'انتهت اللعبة'}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-game-bg/30 rounded-xl p-4 text-center">
                  <div className="text-3xl font-bold text-game-text mb-2">{connectedPlayers.length}</div>
                  <div className="text-game-text-secondary">اللاعبين المتصلين</div>
                </div>
                <div className="bg-game-bg/30 rounded-xl p-4 text-center">
                  <div className="text-3xl font-bold text-game-accent mb-2">{gameState.roomCode || 'غير متصل'}</div>
                  <div className="text-game-text-secondary">رمز الغرفة</div>
                </div>
                <div className="bg-game-bg/30 rounded-xl p-4 text-center">
                  <div className="text-3xl font-bold text-game-success mb-2">
                    {gameState.gameStatus === 'lobby' ? 'اللوبي' : 
                     gameState.gameStatus === 'in_game' ? 'جارية' : 'انتهت'}
                  </div>
                  <div className="text-game-text-secondary">المرحلة الحالية</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Join Game Section */}
          <div className="lg:col-span-2">
            <Card className="bg-game-card/50 backdrop-blur-sm border border-game-border mb-6">
              <CardHeader>
                <CardTitle className="flex items-center text-game-text">
                  <DoorOpen className="text-game-accent text-xl ml-3" />
                  انضم للعبة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-game-text-secondary text-sm font-medium mb-2">
                        <User className="inline ml-2 w-4 h-4" />
                        اسم اللاعب
                      </label>
                      <Input
                        type="text"
                        placeholder="أدخل اسمك هنا"
                        value={playerName}
                        onChange={(e) => setPlayerName(e.target.value)}
                        className="bg-game-bg/50 border-game-border text-game-text placeholder-game-text-secondary"
                        disabled={gameState.isConnected}
                      />
                    </div>
                    <div>
                      <label className="block text-game-text-secondary text-sm font-medium mb-2">
                        <Key className="inline ml-2 w-4 h-4" />
                        رمز الغرفة
                      </label>
                      <Input
                        type="text"
                        placeholder="أدخل رمز الغرفة"
                        value={roomCode}
                        onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                        className="bg-game-bg/50 border-game-border text-game-text placeholder-game-text-secondary"
                        disabled={gameState.isConnected}
                      />
                    </div>
                  </div>
                  
                  <div className="flex space-x-reverse space-x-4">
                    <Button 
                      onClick={handleJoinRoom}
                      disabled={!isConnected || gameState.isConnected}
                      className="flex-1 bg-game-accent hover:bg-red-600 text-white"
                    >
                      <LogIn className="ml-2 w-4 h-4" />
                      انضم للغرفة
                    </Button>
                    <Button 
                      onClick={handleCreateRoom}
                      disabled={!isConnected || gameState.isConnected}
                      variant="secondary"
                      className="bg-game-card hover:bg-gray-700 text-game-text"
                    >
                      <Plus className="ml-2 w-4 h-4" />
                      إنشاء غرفة جديدة
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Game Controls */}
            {gameState.isConnected && (
              <Card className="bg-game-card/50 backdrop-blur-sm border border-game-border">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-game-text">تحكم في اللعبة</CardTitle>
                    <div className="flex items-center space-x-reverse space-x-2">
                      <Button
                        onClick={handleStartGame}
                        disabled={!gameState.isHost || connectedPlayers.length < 3 || gameState.gameStatus !== 'lobby'}
                        className="bg-game-success hover:bg-green-600 text-white"
                      >
                        <Play className="ml-2 w-4 h-4" />
                        بدء اللعبة
                      </Button>
                      <Button
                        onClick={handleStartVote}
                        disabled={!gameState.isHost || gameState.gameStatus !== 'in_game' || gameState.isVoting}
                        className="bg-game-warning hover:bg-yellow-600 text-gray-900"
                      >
                        🗳️ بدء التصويت
                      </Button>
                      <Button
                        onClick={handleResetGame}
                        disabled={!gameState.isHost}
                        variant="secondary"
                        className="bg-game-accent hover:bg-red-600 text-white"
                      >
                        <RotateCcw className="ml-2 w-4 h-4" />
                        إعادة تعيين
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-game-bg/30 rounded-xl p-4 text-center">
                      <div className="text-lg font-bold text-game-text mb-1">6</div>
                      <div className="text-game-text-secondary text-sm">الحد الأقصى</div>
                    </div>
                    <div className="bg-game-bg/30 rounded-xl p-4 text-center">
                      <div className="text-lg font-bold text-game-text mb-1">3</div>
                      <div className="text-game-text-secondary text-sm">الحد الأدنى</div>
                    </div>
                    <div className="bg-game-bg/30 rounded-xl p-4 text-center">
                      <div className="text-lg font-bold text-game-text mb-1">5</div>
                      <div className="text-game-text-secondary text-sm">دقائق</div>
                    </div>
                    <div className="bg-game-bg/30 rounded-xl p-4 text-center">
                      <div className="text-lg font-bold text-game-accent mb-1">1</div>
                      <div className="text-game-text-secondary text-sm">القاتل</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Players List and Chat */}
          <div className="space-y-6">
            {/* Players List */}
            <Card className="bg-game-card/50 backdrop-blur-sm border border-game-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center text-game-text">
                    <Users className="text-game-accent ml-2" />
                    اللاعبين في الغرفة
                  </CardTitle>
                  <Badge className="bg-game-accent/20 text-game-accent">
                    {connectedPlayers.length}/6
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {gameState.players.map((player) => (
                    <div 
                      key={player.id} 
                      className={`flex items-center justify-between p-3 rounded-xl transition-all ${
                        player.isConnected && player.isAlive ? 'bg-game-bg/30 hover:bg-game-bg/50' : 
                        !player.isAlive ? 'bg-red-900/20 border border-red-500/30' : 'bg-game-bg/10'
                      }`}
                    >
                      <div className="flex items-center">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ml-3 ${
                          !player.isAlive ? 'bg-red-900' :
                          player.role === 'killer' ? 'bg-game-accent' :
                          player.role === 'civilian' ? 'bg-game-success' : 'bg-gray-600'
                        }`}>
                          {!player.isAlive ? 
                            <Skull className="text-white text-sm" /> :
                            player.role === 'killer' ? 
                            <Skull className="text-white text-sm" /> : 
                            <User className="text-white text-sm" />
                          }
                        </div>
                        <div>
                          <div className={`font-medium ${
                            !player.isAlive ? 'text-red-400 line-through' :
                            player.isConnected ? 'text-game-text' : 'text-game-text-secondary'
                          }`}>
                            {player.name}
                            {player.isHost && <span className="text-game-warning mr-2">👑</span>}
                            {!player.isAlive && <span className="text-red-400 mr-2">💀</span>}
                          </div>
                          <div className="text-game-text-secondary text-sm">
                            {!player.isAlive ? 'ميت' : 
                             player.isConnected ? 'متصل' : 'غير متصل'}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-reverse space-x-2">
                        <div className={`w-3 h-3 rounded-full ${
                          !player.isAlive ? 'bg-red-600' :
                          player.isConnected ? 'bg-game-success animate-pulse' : 'bg-gray-600'
                        }`}></div>
                        <span className={`text-sm ${
                          !player.isAlive ? 'text-red-400' :
                          player.role === 'killer' ? 'text-game-accent' :
                          player.role === 'civilian' ? 'text-game-success' : 'text-gray-600'
                        }`}>
                          {!player.isAlive ? 'ميت' :
                           player.role === 'killer' ? 'القاتل' : 'لاعب'}
                        </span>
                      </div>
                    </div>
                  ))}
                  {gameState.players.length === 0 && (
                    <div className="text-center py-8 text-game-text-secondary">
                      لا يوجد لاعبين في الغرفة
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Chat System */}
            {gameState.isConnected && (
              <Card className="bg-game-card/50 backdrop-blur-sm border border-game-border">
                <CardHeader>
                  <CardTitle className="flex items-center text-game-text">
                    <MessageCircle className="text-game-accent ml-3" />
                    محادثة الغرفة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64 mb-4">
                    <div className="space-y-3">
                      {gameState.messages.map((message) => (
                        <div key={message.id} className="flex items-start space-x-reverse space-x-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            message.type === 'system' ? 'bg-blue-600' : 'bg-game-success'
                          }`}>
                            {message.type === 'system' ? 
                              <Settings className="text-white text-xs" /> : 
                              <User className="text-white text-xs" />
                            }
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-reverse space-x-2 mb-1">
                              <span className={`font-medium text-sm ${
                                message.type === 'system' ? 'text-blue-400' : 'text-game-text'
                              }`}>
                                {message.senderName}
                              </span>
                              <span className="text-game-text-secondary text-xs">
                                {new Date(message.sentAt).toLocaleTimeString('ar-SA', { 
                                  hour: '2-digit', 
                                  minute: '2-digit' 
                                })}
                              </span>
                            </div>
                            <div className="text-game-text-secondary text-sm">{message.content}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  
                  <div className="flex space-x-reverse space-x-2">
                    <Input
                      type="text"
                      placeholder="اكتب رسالة..."
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      className="flex-1 bg-game-bg/50 border-game-border text-game-text placeholder-game-text-secondary"
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!chatMessage.trim()}
                      className="bg-game-accent hover:bg-red-600 text-white"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Voting Interface */}
        {gameState.isVoting && (
          <Card className="mt-8 bg-game-card/50 backdrop-blur-sm border border-game-border">
            <CardHeader>
              <CardTitle className="flex items-center text-game-text">
                🗳️ التصويت - اختر من تريد طرده
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {gameState.votingPlayers
                  .filter(player => player.id !== gameState.playerId && player.isAlive)
                  .map((player) => (
                    <Button
                      key={player.id}
                      onClick={() => handleVote(player.id)}
                      className="bg-game-accent hover:bg-red-600 text-white p-4 h-auto"
                    >
                      <div className="flex items-center space-x-reverse space-x-3">
                        <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                          <User className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-medium">{player.name}</div>
                          <div className="text-sm opacity-80">اضغط للتصويت</div>
                        </div>
                      </div>
                    </Button>
                  ))}
              </div>
              <div className="mt-4 text-center text-game-text-secondary">
                جولة التصويت #{gameState.votingRound} - اختر بحكمة!
              </div>
            </CardContent>
          </Card>
        )}

        {/* Game Over Modal */}
        {gameState.gameOverData.show && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="bg-game-card border border-game-border max-w-md mx-4">
              <CardHeader>
                <CardTitle className="text-center text-game-text">
                  🏁 انتهت اللعبة!
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="mb-4">
                  <div className="text-2xl font-bold text-game-accent mb-2">
                    الفائز: {gameState.gameOverData.winner}
                  </div>
                  <div className="text-game-text-secondary">
                    {gameState.gameOverData.reason}
                  </div>
                </div>
                
                {gameState.eliminatedPlayers.length > 0 && (
                  <div className="mb-4">
                    <h4 className="text-game-text font-medium mb-2">💀 اللاعبين المطرودين:</h4>
                    <div className="space-y-1">
                      {gameState.eliminatedPlayers.map((player, index) => (
                        <div key={index} className="text-game-text-secondary">
                          ☠️ {player}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <Button
                  onClick={handleRestartGame}
                  className="bg-game-accent hover:bg-red-600 text-white w-full"
                >
                  🔁 إعادة اللعبة
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Killer Actions */}
        {gameState.isConnected && currentPlayer?.role === 'killer' && gameState.gameStatus === 'in_game' && (
          <Card className="mt-8 bg-game-card/50 backdrop-blur-sm border border-game-border">
            <CardHeader>
              <CardTitle className="flex items-center text-game-text">
                🗡️ أفعال القاتل
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {gameState.players
                  .filter(player => player.id !== gameState.playerId && player.isAlive && player.role === 'civilian')
                  .map((player) => (
                    <Button
                      key={player.id}
                      onClick={() => handleKillPlayer(player.id)}
                      variant="destructive"
                      className="bg-game-accent hover:bg-red-600 text-white p-4 h-auto"
                    >
                      <div className="flex items-center space-x-reverse space-x-3">
                        <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                          <Skull className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-medium">{player.name}</div>
                          <div className="text-sm opacity-80">اضغط للقتل</div>
                        </div>
                      </div>
                    </Button>
                  ))}
              </div>
              <div className="mt-4 text-center text-game-text-secondary">
                ⚠️ فقط القاتل يمكنه رؤية هذا القسم
              </div>
            </CardContent>
          </Card>
        )}

        {/* Game Rules Section */}
        <Card className="mt-8 bg-game-card/50 backdrop-blur-sm border border-game-border">
          <CardHeader>
            <CardTitle className="flex items-center text-game-text">
              <Shield className="text-game-accent ml-3" />
              قواعد اللعبة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-game-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Skull className="text-game-accent text-2xl" />
                </div>
                <h4 className="text-game-text font-medium mb-2">القاتل</h4>
                <p className="text-game-text-secondary text-sm">يجب على القاتل التخلص من جميع اللاعبين دون أن يكتشف أمره</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-game-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="text-game-success text-2xl" />
                </div>
                <h4 className="text-game-text font-medium mb-2">المدنيون</h4>
                <p className="text-game-text-secondary text-sm">يجب على المدنيين اكتشاف القاتل وإخراجه من اللعبة</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-game-warning/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="text-game-warning text-2xl" />
                </div>
                <h4 className="text-game-text font-medium mb-2">الوقت</h4>
                <p className="text-game-text-secondary text-sm">لديك 5 دقائق للنقاش والتصويت على من تعتقد أنه القاتل</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-game-card/30 backdrop-blur-sm border-t border-game-border mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="text-game-text-secondary text-sm">
              <p>&copy; 2024 من هو القاتل؟ - لعبة متعددة اللاعبين</p>
            </div>
            <div className="flex items-center space-x-reverse space-x-4">
              <div className="text-game-text-secondary text-sm">
                مدعوم بـ WebSocket
              </div>
              <Heart className="text-game-accent w-4 h-4" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
