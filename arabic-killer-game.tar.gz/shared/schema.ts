import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  hostId: integer("host_id").notNull(),
  maxPlayers: integer("max_players").notNull().default(6),
  status: text("status").notNull().default("lobby"), // lobby, in_game, finished
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  roomId: integer("room_id").notNull(),
  isHost: boolean("is_host").notNull().default(false),
  role: text("role").default("civilian"), // civilian, killer
  isAlive: boolean("is_alive").notNull().default(true),
  isConnected: boolean("is_connected").notNull().default(true),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  playerId: integer("player_id"),
  senderName: text("sender_name").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull().default("chat"), // chat, system
  sentAt: timestamp("sent_at").notNull().defaultNow(),
});

export const votes = pgTable("votes", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  voterId: integer("voter_id").notNull(),
  targetId: integer("target_id").notNull(),
  voteRound: integer("vote_round").notNull().default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const gameRounds = pgTable("game_rounds", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull(),
  round: integer("round").notNull().default(1),
  phase: text("phase").notNull().default("discussion"), // discussion, voting, night
  eliminatedPlayerId: integer("eliminated_player_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertRoomSchema = createInsertSchema(rooms).omit({
  id: true,
  createdAt: true,
});

export const insertPlayerSchema = createInsertSchema(players).omit({
  id: true,
  joinedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  sentAt: true,
});

export const insertVoteSchema = createInsertSchema(votes).omit({
  id: true,
  createdAt: true,
});

export const insertGameRoundSchema = createInsertSchema(gameRounds).omit({
  id: true,
  createdAt: true,
});

export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertVote = z.infer<typeof insertVoteSchema>;
export type InsertGameRound = z.infer<typeof insertGameRoundSchema>;

export type Room = typeof rooms.$inferSelect;
export type Player = typeof players.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Vote = typeof votes.$inferSelect;
export type GameRound = typeof gameRounds.$inferSelect;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
